from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui' # Necessário para usar session no Flask

def conectar_banco():
    conexao = sqlite3.connect('folha_pagamento.db')
    conexao.row_factory = sqlite3.Row
    return conexao

# --- Decorators de Controle de Acesso ---
def login_obrigatorio(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('pagina_login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_rh_obrigatorio(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('nivel_acesso') != 1:
            return jsonify({'erro': 'Acesso negado. Apenas RH/Admin.'}), 403
        return f(*args, **kwargs)
    return decorated_function

# --- RNF004: Orientação a Objetos com Regras Progressivas ---
class CalculoRemuneracao:
    def calcular(self, salario_base, dados_extras):
        return 0, salario_base

class CalculoComissionado(CalculoRemuneracao):
    def calcular(self, salario_base, dados_extras):
        vendas = float(dados_extras.get('valor_vendas', 0))
        meta = float(dados_extras.get('meta_vendas', 1)) # Evita divisão por zero
        comissao = float(dados_extras.get('percentual_comissao', 0))

        if vendas < meta:
            return 0, salario_base # Meta não batida = 0 comissão

        # Comissão progressiva: Taxa base até a meta, Taxa 1.5x no que exceder
        adicionais = meta * (comissao / 100.0)
        if vendas > meta:
            adicionais += (vendas - meta) * ((comissao * 1.5) / 100.0)
            
        return adicionais, salario_base + adicionais

class CalculoProducao(CalculoRemuneracao):
    def calcular(self, salario_base, dados_extras):
        qtd = int(dados_extras.get('quantidade_produzida', 0))
        meta = int(dados_extras.get('meta_producao', 1))
        valor_un = float(dados_extras.get('valor_unidade', 0))

        if qtd < meta:
            return 0, salario_base

        adicionais = meta * valor_un
        if qtd > meta:
            adicionais += (qtd - meta) * (valor_un * 1.5)
            
        return adicionais, salario_base + adicionais

def processar_salario(tipo, base, extras):
    estrategias = {'Padrão': CalculoRemuneracao(), 'Comissionado': CalculoComissionado(), 'Producao': CalculoProducao()}
    return estrategias.get(tipo, CalculoRemuneracao()).calcular(base, extras)

# --- Rotas de Autenticação ---
@app.route('/login', methods=['GET', 'POST'])
def pagina_login():
    if request.method == 'POST':
        matricula = request.form['matricula']
        senha = request.form['senha']
        
        conexao = conectar_banco()
        cursor = conexao.cursor()
        cursor.execute('SELECT * FROM Colaborador WHERE matricula = ? AND status = "Ativo"', (matricula,))
        usuario = cursor.fetchone()
        conexao.close()
        
        if usuario and check_password_hash(usuario['senha_hash'], senha):
            session['usuario_id'] = usuario['matricula']
            session['nivel_acesso'] = usuario['nivel_acesso']
            return redirect(url_for('index'))
        return render_template('login.html', erro="Matrícula ou senha incorretos, ou usuário inativo.")
        
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('pagina_login'))

# --- Rotas de Interface Protegidas ---
@app.route('/')
@login_obrigatorio
def index():
    return render_template('lista.html', nivel_acesso=session['nivel_acesso'], usuario_id=session['usuario_id'])

# --- API e Exclusão Lógica (Soft Delete) ---
@app.route('/api/colaboradores/<int:matricula>', methods=['DELETE'])
@login_obrigatorio
@admin_rh_obrigatorio
def desabilitar_colaborador(matricula):
    # A exclusão agora apenas muda o status para 'Inativo'
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute('UPDATE Colaborador SET status = "Inativo" WHERE matricula = ?', (matricula,))
    conexao.commit()
    conexao.close()
    return jsonify({'mensagem': 'Usuário desabilitado com sucesso!'})

@app.route('/api/colaboradores', methods=['GET'])
@login_obrigatorio
def listar_colaboradores():
    conexao = conectar_banco()
    cursor = conexao.cursor()
    
    # Restrição de Nível 3 (Usuário comum só vê a si mesmo)
    if session['nivel_acesso'] == 3:
        cursor.execute('SELECT * FROM Colaborador WHERE matricula = ?', (session['usuario_id'],))
    else:
        cursor.execute('SELECT * FROM Colaborador')
        
    lista = [dict(linha) for linha in cursor.fetchall()]
    conexao.close()
    return jsonify(lista)

# ==========================================
# ROTAS DE RENDERIZAÇÃO DAS TELAS (HTML)
# ==========================================
@app.route('/cadastro')
@login_obrigatorio
@admin_rh_obrigatorio # Apenas Nível 1
def pagina_cadastro():
    return render_template('cadastro.html')

@app.route('/alterar/<int:matricula>')
@login_obrigatorio
@admin_rh_obrigatorio # Apenas Nível 1
def pagina_alterar(matricula):
    return render_template('alterar.html', matricula=matricula)

@app.route('/folha/<int:matricula>')
@login_obrigatorio
def pagina_folha_individual(matricula):
    # Nível 3 só pode ver a própria folha
    if session['nivel_acesso'] == 3 and session['usuario_id'] != matricula:
        return "Acesso Negado: Você só pode acessar sua própria folha.", 403
    return render_template('folha_individual.html', matricula=matricula)

@app.route('/relatorios')
@login_obrigatorio
def pagina_relatorios():
    # Nível 3 não tem acesso ao relatório geral
    if session['nivel_acesso'] == 3:
        return "Acesso Negado: Relatório restrito ao RH e Financeiro.", 403
    return render_template('relatorios.html')

# ==========================================
# APIs DE CADASTRO, ALTERAÇÃO E CÁLCULO DA FOLHA
# ==========================================
@app.route('/api/colaboradores', methods=['POST'])
@login_obrigatorio
@admin_rh_obrigatorio
def cadastrar_colaborador():
    dados = request.json
    nome = dados.get('nome')
    salario_base = dados.get('salario_base')
    tipo = dados.get('tipo_colaborador')
    senha = generate_password_hash(dados.get('senha', '123456')) # Senha padrão se vazio
    nivel_acesso = int(dados.get('nivel_acesso', 3))

    conexao = conectar_banco()
    cursor = conexao.cursor()
    try:
        cursor.execute('''
            INSERT INTO Colaborador (nome, salario_base, tipo_colaborador, senha_hash, nivel_acesso) 
            VALUES (?, ?, ?, ?, ?)
        ''', (nome, salario_base, tipo, senha, nivel_acesso))
        matricula = cursor.lastrowid

        if tipo == 'Comissionado':
            cursor.execute('INSERT INTO Colaborador_Comissionado (matricula_colaborador, meta_vendas, valor_vendas, percentual_comissao) VALUES (?, ?, ?, ?)',
                           (matricula, float(dados.get('meta_vendas', 0)), 0, float(dados.get('percentual_comissao', 0))))
        elif tipo == 'Producao':
            cursor.execute('INSERT INTO Colaborador_Producao (matricula_colaborador, meta_producao, quantidade_produzida, valor_unidade) VALUES (?, ?, ?, ?)',
                           (matricula, int(dados.get('meta_producao', 0)), 0, float(dados.get('valor_unidade', 0))))
        conexao.commit()
        return jsonify({'mensagem': 'Colaborador cadastrado com sucesso!'})
    except Exception as e:
        conexao.rollback()
        return jsonify({'erro': str(e)}), 400
    finally:
        conexao.close()

@app.route('/api/folha/<int:matricula>')
@login_obrigatorio
def calcular_folha_individual(matricula):
    if session['nivel_acesso'] == 3 and session['usuario_id'] != matricula:
        return jsonify({'erro': 'Acesso negado'}), 403

    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute('SELECT * FROM Colaborador WHERE matricula = ?', (matricula,))
    colab = cursor.fetchone()

    if not colab:
        conexao.close()
        return jsonify({'erro': 'Colaborador não encontrado'}), 404

    extras = {}
    if colab['tipo_colaborador'] == 'Comissionado':
        cursor.execute('SELECT * FROM Colaborador_Comissionado WHERE matricula_colaborador = ?', (matricula,))
        extras = dict(cursor.fetchone() or {})
    elif colab['tipo_colaborador'] == 'Producao':
        cursor.execute('SELECT * FROM Colaborador_Producao WHERE matricula_colaborador = ?', (matricula,))
        extras = dict(cursor.fetchone() or {})
    
    conexao.close()

    adicionais, salario_final = processar_salario(colab['tipo_colaborador'], colab['salario_base'], extras)

    return jsonify({
        'matricula': colab['matricula'],
        'nome': colab['nome'],
        'tipo': colab['tipo_colaborador'],
        'salario_base': colab['salario_base'],
        'adicionais': adicionais,
        'salario_final': salario_final,
        'detalhes_calculo': 'Baseado na meta e produção do mês'
    })

@app.route('/api/folha_consolidada')
@login_obrigatorio
def folha_consolidada():
    if session['nivel_acesso'] == 3:
        return jsonify({'erro': 'Acesso negado'}), 403

    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute('SELECT matricula FROM Colaborador WHERE status = "Ativo"')
    matriculas = cursor.fetchall()
    conexao.close()

    total_folha = 0
    detalhes = []
    
    # Reutiliza a lógica da API individual (em um sistema real, faríamos um JOIN direto no banco)
    with app.test_client() as client:
        with client.session_transaction() as sess:
            sess['nivel_acesso'] = 1 # Força permissão para gerar em lote
            
        for m in matriculas:
            resposta = client.get(f'/api/folha/{m["matricula"]}')
            if resposta.status_code == 200:
                dados = resposta.get_json()
                total_folha += dados['salario_final']
                detalhes.append(dados)

    return jsonify({
        'total_folha': total_folha,
        'quantidade_colaboradores': len(detalhes),
        'detalhes': detalhes
    })

if __name__ == '__main__':
    app.run(port=5000, debug=True)