import sqlite3
from werkzeug.security import generate_password_hash

def inicializar_banco():
    conexao = sqlite3.connect('folha_pagamento.db')
    cursor = conexao.cursor()

    # Tabela principal com novos campos (Soft Delete, Nível de Acesso, Datas)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Colaborador (
        matricula INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        salario_base REAL NOT NULL,
        tipo_colaborador TEXT NOT NULL,
        senha_hash TEXT NOT NULL,
        nivel_acesso INTEGER NOT NULL, -- 1: Admin/RH, 2: Financeiro, 3: Comum
        status TEXT DEFAULT 'Ativo', -- 'Ativo' ou 'Inativo' (Substitui o Delete)
        data_cadastro DATE DEFAULT CURRENT_DATE,
        data_nascimento DATE,
        data_fim_contrato DATE
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Colaborador_Comissionado (
        matricula_colaborador INTEGER PRIMARY KEY,
        meta_vendas REAL NOT NULL,
        valor_vendas REAL NOT NULL,
        percentual_comissao REAL NOT NULL,
        FOREIGN KEY (matricula_colaborador) REFERENCES Colaborador(matricula)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Colaborador_Producao (
        matricula_colaborador INTEGER PRIMARY KEY,
        meta_producao INTEGER NOT NULL,
        quantidade_produzida INTEGER NOT NULL,
        valor_unidade REAL NOT NULL,
        FOREIGN KEY (matricula_colaborador) REFERENCES Colaborador(matricula)
    )
    ''')

    # Tabela de Histórico Financeiro
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Historico_Remuneracao (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        matricula_colaborador INTEGER,
        mes_ano TEXT NOT NULL, -- Ex: '10/2026'
        meta_atingida REAL,
        valor_recebido REAL NOT NULL,
        FOREIGN KEY (matricula_colaborador) REFERENCES Colaborador(matricula)
    )
    ''')

    # Criação do primeiro usuário Administrador para não trancar o sistema
    cursor.execute('SELECT * FROM Colaborador WHERE nivel_acesso = 1')
    if not cursor.fetchone():
        senha_admin = generate_password_hash('admin123')
        cursor.execute('''
        INSERT INTO Colaborador (nome, salario_base, tipo_colaborador, senha_hash, nivel_acesso) 
        VALUES ('Administrador Master', 5000, 'Padrão', ?, 1)
        ''', (senha_admin,))

    conexao.commit()
    conexao.close()
    print("Banco de dados recriado com sucesso!")

if __name__ == '__main__':
    inicializar_banco()